/*
 * package com.springBootAction.repository;
 * 
 * import org.springframework.boot.autoconfigure.domain.EntityScan; import
 * org.springframework.stereotype.Repository;
 * 
 * @EntityScan
 * 
 * @Table(name = "user_data", schema = "product") public class UserData {
 * 
 * @Id
 * 
 * @GeneratedValue
 * 
 * @Column(name="rating_id") private Long ratingId; private double rating;
 * 
 * @Column(name="product_id") private String productId;
 * 
 * @Column(name="user_id") private String userId; public Rating() { } public
 * Rating(Long ratingId, double rating, String productId, String userId) {
 * super(); this.ratingId = ratingId; this.rating = rating; this.productId =
 * productId; this.userId = userId; } //getters, setters, toString, hashCode,
 * equals }
 */