package com.springBootAction;

import org.apache.catalina.connector.Connector;
import org.apache.coyote.http11.AbstractHttp11Protocol;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.context.annotation.Bean;


@SpringBootApplication
public class SpringBootProjectApplication {

	public static void main(String[] args) {
		System.out.println("\n in main class>>>>>>>>111>>>>>");
		SpringApplication.run(SpringBootProjectApplication.class, args);
	}
	
	@Bean
    public TomcatServletWebServerFactory containerFactory() {
        return new TomcatServletWebServerFactory() {
            protected void customizeConnector(Connector connector) {
                //int maxSize = 50000000;
                super.customizeConnector(connector);
                connector.setMaxPostSize(-1);
                connector.setMaxSavePostSize(-1);
                if (connector.getProtocolHandler() instanceof AbstractHttp11Protocol<?>) {

                    ((AbstractHttp11Protocol <?>) connector.getProtocolHandler()).setMaxSwallowSize(-1);
                   // logger.info("Set MaxSwallowSize "+ maxSize);
                }
            }
        };

    }

}

/*
 * @Override public void run(String... args) throws Exception {
 * System.out.println("\n in runner>>>>>"); main(new String[]
 * {"from runner agrument"}); }}
 */
