package com.springBootAction.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class SpringBootController {

	@Autowired
	private ServletContext servletContext;

	private static final String DIRECTORY = "C:\\\\Users\\\\vkaushik10\\\\Desktop\\\\";
	private static String UPLOADED_FOLDER = "C:\\Users\\vkaushik10\\Desktop\\";

	@GetMapping("/localDownload/{fileName:.+}")
	public ResponseEntity downloadFile1(@PathVariable("fileName") String fileName,
			RedirectAttributes redirectAttributes) throws IOException {

		String mineType = servletContext.getMimeType(fileName);
		MediaType mediaType = MediaType.parseMediaType(mineType);
		System.out.println("fileName: " + fileName);
		System.out.println("mediaType: " + mediaType);

		File file = new File(DIRECTORY + "/" + fileName);
		InputStreamResource resource = null;
		if (file.exists() || file.isFile()) {
			resource = new InputStreamResource(new FileInputStream(file));
			double size = (double) file.length() / (1024 * 1024);
			if (size > 10) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body("file size exceed maximum limit of 10 mb. current requested file is " + size + "mb.");

			}
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("file not found!!!!");
		}

		/*
		 * for URL based download
		 * 
		 * InputStreamResource resource = new InputStreamResource(new
		 * URL("").openStream());
		 * 
		 */

		return ResponseEntity.ok()

				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName())

				.contentType(mediaType)

				.contentLength(file.length()) //
				.body(resource);
	}

	@GetMapping("/")	
	public String index() {
		return "upload";
	}

	@PostMapping("/upload") // //new annotation since 4.3
	public String singleFileUpload(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {

		if (file.isEmpty()) {
			redirectAttributes.addFlashAttribute("message", "Please select a file to upload");
			return "redirect:uploadStatus";
		}

		try {

			// Get the file and save it somewhere
			byte[] bytes = file.getBytes();
			Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
			Files.write(path, bytes);

			redirectAttributes.addFlashAttribute("message",
					"You successfully uploaded '" + file.getOriginalFilename() + "'");

		} catch (IOException e) {
			e.printStackTrace();
		}

		return "redirect:/uploadStatus";
	}

	@GetMapping("/uploadStatus")
	public String uploadStatus() {
		return "uploadStatus";
	}

}
