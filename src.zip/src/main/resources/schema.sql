create table if not exists User (id int(11) not null, name varchar(25) not null);
